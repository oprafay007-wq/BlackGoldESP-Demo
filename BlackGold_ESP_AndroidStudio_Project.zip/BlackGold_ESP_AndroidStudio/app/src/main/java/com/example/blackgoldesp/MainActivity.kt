package com.example.blackgoldesp

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.RectF
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Switch
import android.widget.Button
import android.graphics.Typeface
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val gold = Color.rgb(212, 175, 55)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 28, 20, 18)
            setBackgroundColor(Color.rgb(9, 9, 11))
        }
        root.addView(TextView(this).apply {
            text = "BLACK / GOLD ESP DEMO"
            textSize = 22f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "SIMULATED TRAINING VIEW • NOT CONNECTED TO FREE FIRE"
            textSize = 10f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 16)
        })
        val preview = EspPreview(this)
        root.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 10)
            setBackgroundColor(Color.rgb(25, 23, 17))
        }
        fun toggle(label: String, initial: Boolean, change: (Boolean) -> Unit) {
            panel.addView(Switch(this).apply {
                text = label
                setTextColor(Color.WHITE)
                isChecked = initial
                setOnCheckedChangeListener { _, checked -> change(checked) }
            })
        }
        toggle("Player boxes", true) { preview.boxes = it; preview.invalidate() }
        toggle("Names & distance", true) { preview.labels = it; preview.invalidate() }
        toggle("Health bars", true) { preview.health = it; preview.invalidate() }
        toggle("Skeleton lines", false) { preview.skeleton = it; preview.invalidate() }
        panel.addView(Button(this).apply {
            text = "RESET DEMO"
            setTextColor(Color.BLACK)
            setBackgroundColor(gold)
            setOnClickListener { preview.reset() }
        })
        root.addView(panel)
        setContentView(root)
    }
}

class EspPreview(context: android.content.Context) : View(context) {
    var boxes = true
    var labels = true
    var health = true
    var skeleton = false
    private val gold = Color.rgb(212, 175, 55)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun reset() {
        boxes = true; labels = true; health = true; skeleton = false
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(15, 17, 19))
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(28, 31, 32)
        canvas.drawRect(0f, height * .68f, width.toFloat(), height.toFloat(), paint)
        paint.color = Color.rgb(44, 48, 48)
        canvas.drawLine(0f, height * .68f, width.toFloat(), height * .68f, paint)
        val targets = listOf(
            Target(width * .22f, height * .43f, "BOT-01", "24m", .82f),
            Target(width * .57f, height * .36f, "BOT-02", "41m", .56f),
            Target(width * .80f, height * .50f, "BOT-03", "17m", .94f)
        )
        targets.forEach { target ->
            val rect = RectF(target.x - 34f, target.y - 76f, target.x + 34f, target.y + 76f)
            if (boxes) {
                paint.color = gold; paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f
                canvas.drawRoundRect(rect, 5f, 5f, paint)
            }
            if (health) {
                paint.style = Paint.Style.FILL; paint.color = Color.DKGRAY
                canvas.drawRect(rect.left - 9f, rect.top, rect.left - 4f, rect.bottom, paint)
                paint.color = Color.rgb(80, 220, 130)
                canvas.drawRect(rect.left - 9f, rect.bottom - 152f * target.hp, rect.left - 4f, rect.bottom, paint)
            }
            if (labels) {
                paint.style = Paint.Style.FILL; paint.textSize = 12f; paint.typeface = Typeface.DEFAULT_BOLD
                paint.color = gold
                canvas.drawText(target.name, rect.left - 4f, rect.top - 12f, paint)
                paint.color = Color.WHITE; paint.typeface = Typeface.DEFAULT
                canvas.drawText(target.distance, rect.left - 4f, rect.bottom + 18f, paint)
            }
            if (skeleton) drawSkeleton(canvas, target.x, target.y)
        }
        paint.style = Paint.Style.FILL; paint.color = Color.LTGRAY; paint.textSize = 11f
        canvas.drawText("SIMULATED TARGETS", 16f, 24f, paint)
        canvas.drawText("NO GAME MEMORY / NETWORK ACCESS", 16f, height - 16f, paint)
    }

    private fun drawSkeleton(canvas: Canvas, x: Float, y: Float) {
        paint.color = gold; paint.strokeWidth = 2.5f; paint.style = Paint.Style.STROKE
        val headY = y - 52f
        canvas.drawCircle(x, headY, 11f, paint)
        canvas.drawLine(x, headY + 11, x, y + 20, paint)
        canvas.drawLine(x, y - 18, x - 24, y + 8, paint)
        canvas.drawLine(x, y - 18, x + 24, y + 8, paint)
        canvas.drawLine(x, y + 20, x - 18, y + 65, paint)
        canvas.drawLine(x, y + 20, x + 18, y + 65, paint)
    }

    data class Target(val x: Float, val y: Float, val name: String, val distance: String, val hp: Float)
}
